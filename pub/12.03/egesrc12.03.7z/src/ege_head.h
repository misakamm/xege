/*
* EGE (Easy Graphics Engine)
* filename  ege_head.cpp

��������ͷ�ļ���˽�У�������ʹ�ã�
*/

#ifndef _EGE_HEAD_H_
#define _EGE_HEAD_H_

#ifndef _ALLOW_ITERATOR_DEBUG_LEVEL_MISMATCH
#define _ALLOW_ITERATOR_DEBUG_LEVEL_MISMATCH
#endif

#if !defined(_MSC_VER) || _MSC_VER > 1300
#include "stdint.h"
#endif

#define _GRAPH_LIB_BUILD_
#include "ege.h"

#ifndef ERROR_SUCCESS
#define ERROR_SUCCESS 0
#endif

#ifndef ASSERT_TRUE
#ifdef _DEBUG
#include <cassert>
#define ASSERT_TRUE(e) assert((e) != MUSIC_ERROR)
#else
#define ASSERT_TRUE(e) (void(0))
#endif
#endif

#define QUEUE_LEN           1024
#define BITMAP_PAGE_SIZE    4
#define UPDATE_MAX_CALL     0xFF
#define RENDER_TIMER_ID     916
#define IMAGE_INIT_FLAG     0x20100916
#define MAX_KEY_VCODE       256
#define FLOAT_EPS           1e-3f


#ifndef SWAP
#define SWAP(_a, _b, _t) {_t = _a; _a = _b; _b = _t; }
#endif

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#define IFATODOB(A, B)  ( (A) && (B, 0) )
#define IFNATODOB(A, B) ( (A) || (B, 0) )

#define CONVERT_IMAGE(pimg) ( IFNATODOB(graph_setting.lock_window, EnterCriticalSection(&graph_setting.cs_render)), ((size_t)(pimg)<0x20 ?\
        ((pimg) ?\
            (IFATODOB(((size_t)(pimg)&0xF)==(size_t)graph_setting.visual_page, graph_setting.update_mark_count -= 1), graph_setting.img_page[(size_t)(pimg) & 0xF])\
        : (IFATODOB(graph_setting.visual_page==graph_setting.active_page, graph_setting.update_mark_count -= 1) , graph_setting.imgtarget))\
    : pimg) )

#define CONVERT_IMAGE_CONST(pimg) ( IFNATODOB(graph_setting.lock_window, EnterCriticalSection(&graph_setting.cs_render)), (size_t)(pimg)<0x20 ?\
        ((pimg) ?\
            graph_setting.img_page[(size_t)(pimg) & 0xF]\
        : graph_setting.imgtarget)\
    : pimg)

#define CONVERT_IMAGE_F(pimg) ((size_t)(pimg)<0x20 ?\
    ((pimg) ?\
    (IFATODOB(((size_t)(pimg)&0xF)==(size_t)graph_setting.visual_page, graph_setting.update_mark_count -= 1), graph_setting.img_page[(size_t)(pimg) & 0xF])\
    : (IFATODOB(graph_setting.visual_page==graph_setting.active_page, graph_setting.update_mark_count -= 1) , graph_setting.imgtarget))\
    : pimg)

#define CONVERT_IMAGE_F_CONST(pimg) ((size_t)(pimg)<0x20 ?\
    ((pimg) ?\
    graph_setting.img_page[(size_t)(pimg) & 0xF]\
    : graph_setting.imgtarget)\
    : pimg)

#define CONVERT_IMAGE_END ( IFNATODOB(graph_setting.lock_window, LeaveCriticalSection(&graph_setting.cs_render)))

#ifndef DEFAULT_CHARSET
#define DEFAULT_CHARSET ANSI_CHARSET
#endif

#if !defined(_W64)
#if !defined(__midl) && (defined(_X86_) || defined(_M_IX86)) && _MSC_VER >= 1300
#define _W64 __w64
#else
#define _W64
#endif
#endif

#ifndef __int3264
#if defined(_WIN64)
typedef __int64 LONG_PTR, *PLONG_PTR;
typedef unsigned __int64 ULONG_PTR, *PULONG_PTR;

#define __int3264   __int64

#else
typedef _W64 long LONG_PTR, *PLONG_PTR;
typedef _W64 unsigned long ULONG_PTR, *PULONG_PTR;

#define __int3264   __int32

#endif
#endif

typedef ULONG_PTR DWORD_PTR, *PDWORD_PTR;

typedef unsigned long uint32;

typedef size_t POINTER_SIZE;

namespace ege {

struct EMSG {
    HWND        hwnd;
    UINT        message;
    WPARAM      wParam;
    LPARAM      lParam;
    DWORD       time;
    UINT        mousekey;
    UINT        flag;
};

struct msg_queue{
    EMSG    msg_Queue[QUEUE_LEN]; //��Ϣ�б�
    int     msg_pt_w, msg_pt_r;
    EMSG    msg_last;
};

struct _graph_setting {
    struct _graph {
        int width;
        int height;
    }graph;
    struct _aspectratio {
        float xasp, yasp;
    }aspectratio;

    int writemode;

    HDC dc;
    HDC window_dc;
    int dc_w, dc_h;
    PIMAGE img_page[BITMAP_PAGE_SIZE];
    int base_x, base_y, base_w, base_h;

    int     visual_page;
    int     active_page;
    PIMAGE  imgtarget;
    PIMAGE  imgtarget_set;

    HINSTANCE instance;
    HWND    hwnd;
    TCHAR   window_class_name[32];
    TCHAR   window_caption[128];
    int     exit_flag;
    int     exit_window;
    int     update_mark_count; //���±��
    bool    close_manually;
    bool    use_force_exit; //ǿ�ƹرս��̱��
    bool    lock_window;
    bool    init_finish;
    bool    timer_stop_mark;
    bool    skip_timer_mark;

    msg_queue msgkey_queue, msgmouse_queue;

    CRITICAL_SECTION cs_msgqueue, cs_callbackmessage;
    CRITICAL_SECTION cs_render;
    HANDLE threadui_handle;


    /*���״̬��¼*/
    int mouse_state_l, mouse_state_m, mouse_state_r;
    int mouse_last_x, mouse_last_y;
    int mouse_lastclick_x, mouse_lastclick_y;
    //int mouse_click_cnt_l, mouse_click_cnt_m, mouse_click_cnt_r;
    int mouse_lastup_x, mouse_lastup_y;
    //int g_up_cnt_l, g_up_cnt_m, g_up_cnt_r;
    int mouse_show;

    LPMSG_KEY_PROC callback_key;
    void* callback_key_param;
    LPMSG_MOUSE_PROC callback_mouse;
    void* callback_mouse_param;
    LPCALLBACK_PROC callback_close;

    /* ����״̬��¼ */
    int keystatemap[MAX_KEY_VCODE];

    /* egeControlBase */
    egeControlBase* egectrl_root;
    egeControlBase* egectrl_focus;

    /* ˽��ȫ�ֱ��� */
    LARGE_INTEGER get_highfeq_time_start;
    //double delay_dwLast;
    double delay_ms_dwLast;
    double delay_fps_dwLast;
    int getch_last_key;

    HBRUSH savebrush_hbr;

    /* ��������ʱ������ */
    DWORD g_t_buff[1024 * 8];
};

extern struct _graph_setting& graph_setting;

} // namespace ege

#endif /*_EGE_HEAD_H_*/
