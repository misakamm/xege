/*
* EGE (Easy Graphics Engine)
* filename  egegapi.cpp

���ļ��㼯�϶����ĺ����ӿ�
*/
#include "ege_head.h"

#include <math.h>

#include "lpng/zlib.h"

namespace ege {

int dealmessage(_graph_setting* pg, int getmsg);
void guiupdate(_graph_setting* pg, egeControlBase* &root);
float _GetFPS(int add);
int getflush();

LONGLONG
get_highfeq_time_ls(struct _graph_setting * pg) {
    static LARGE_INTEGER llFeq = {{0}}; /* ��ʵΪ���� */
    LARGE_INTEGER llNow = {{0}};

    if (pg->get_highfeq_time_start.QuadPart == 0) {
        QueryPerformanceCounter(&pg->get_highfeq_time_start);
        QueryPerformanceFrequency(&llFeq);
        return 0;
    } else {
        QueryPerformanceCounter(&llNow);
        llNow.QuadPart -= pg->get_highfeq_time_start.QuadPart;
        return llNow.QuadPart * 10000 / llFeq.QuadPart;
    }
}

bool
is_run() {
    struct _graph_setting * pg = &graph_setting;
    if (pg->exit_window || pg->exit_flag) return false;
    return true;
}

void
setcaption(LPCSTR  caption) {
    ::SetWindowTextA(GetHWnd(), caption);
}
void
setcaption(LPCWSTR caption) {
    ::SetWindowTextW(GetHWnd(), caption);
}

void
api_sleep(DWORD dwMilliseconds) {
    ::Sleep(dwMilliseconds);
}

void
delay(int ms) {
    delay_ms(ms);
}

void
delay_ms(int ms) {
    struct _graph_setting * pg = &graph_setting;
    egeControlBase* &root = pg->egectrl_root;
    pg->skip_timer_mark = true;
    //LeaveCriticalSection(&pg->cs_callbackmessage);
    if (ms == 0) {
        if (pg->update_mark_count < UPDATE_MAX_CALL) {
            Sleep(1);
            pg->update_mark_count = 0;
            root->draw(NULL);
            dealmessage(pg, 1);
            root->update();
            {
                int l,t,r,b,c;
                getviewport(&l, &t, &r, &b, &c);
                setviewport(l, t, r, b, c);
            }
        }
        pg->delay_ms_dwLast = get_highfeq_time_ls(pg)*60.0;
        //EnterCriticalSection(&pg->cs_callbackmessage);
        pg->skip_timer_mark = false;
        return;
    }
    {
        double delay_time = ms * 600.0;
        double dw = get_highfeq_time_ls(pg)*60.0;
        int f = 100;

        if (ms >= 50) {
            f = 0;
        }
        pg->delay_ms_dwLast = 0;
        if (pg->delay_ms_dwLast == 0) {
            pg->delay_ms_dwLast = get_highfeq_time_ls(pg)*60.0;
        }
        if (pg->delay_ms_dwLast + 60000 > dw) {
            dw = pg->delay_ms_dwLast;
        }

        //Sleep(1);
        root->draw(NULL);
        while (dw + delay_time >= get_highfeq_time_ls(pg)*60.0) {
            if ( f <= 0 || pg->update_mark_count < UPDATE_MAX_CALL) {
                pg->update_mark_count = 0;
                dealmessage(pg, 1);
                f = 256;
            } else {
                Sleep(1);
            }
            f -= 1;
        }
        pg->update_mark_count = 0;
        dealmessage(pg, 1);
        dw = get_highfeq_time_ls(pg) * 60.0;
        guiupdate(pg, root);
        if (pg->delay_ms_dwLast + 60000 <= dw || pg->delay_ms_dwLast > dw) {
            pg->delay_ms_dwLast = dw;
        } else {
            pg->delay_ms_dwLast += delay_time;
        }
    }
    //EnterCriticalSection(&pg->cs_callbackmessage);
    pg->skip_timer_mark = false;
    {   //�����������޷����µ���ʱ����
        int l,t,r,b,c;
        getviewport(&l, &t, &r, &b, &c);
        setviewport(l, t, r, b, c);
    }
}

/*
�ӳ�1/fps��ʱ�䣬���ü��������100msʱ�ܱ�֤ÿ���ܷ���fps��
*/
void
delay_fps(int fps) {
    struct _graph_setting * pg = &graph_setting;
    egeControlBase* &root = pg->egectrl_root;
    pg->skip_timer_mark = true;
    //LeaveCriticalSection(&pg->cs_callbackmessage);
    double delay_time = 600000.0/fps;
    double dw = get_highfeq_time_ls(pg)*60.0;
    int nloop = 0;

    if (pg->delay_fps_dwLast == 0) {
        pg->delay_fps_dwLast = get_highfeq_time_ls(pg)*60.0;
    }
    if (pg->delay_fps_dwLast + 60000 > dw) {
        dw = pg->delay_fps_dwLast;
    }
    root->draw(NULL);
    for (; nloop>=0; --nloop) {
        if ((dw + delay_time + (30 * 600.0) >= get_highfeq_time_ls(pg)*60.0)) {
            do {
                Sleep(1);
            } while (dw + delay_time >= get_highfeq_time_ls(pg)*60.0);
        }
        pg->update_mark_count = 0;
        dealmessage(pg, !nloop);
        dw = get_highfeq_time_ls(pg)*60.0;
        guiupdate(pg, root);
        if (pg->delay_fps_dwLast + 60000 <= dw || pg->delay_fps_dwLast > dw) {
            pg->delay_fps_dwLast = dw;
        } else {
            pg->delay_fps_dwLast += delay_time;
        }
    }
    //EnterCriticalSection(&pg->cs_callbackmessage);
    pg->skip_timer_mark = false;
    {   //�����������޷����µ���ʱ����
        int l,t,r,b,c;
        getviewport(&l, &t, &r, &b, &c);
        setviewport(l, t, r, b, c);
    }
}

/*
�ӳ�1/fps��ʱ�䣬���ü��������100msʱ�ܱ�֤ÿ���ܷ���fps��
*/
void
delay_jfps(int fps) {
    struct _graph_setting * pg = &graph_setting;
    egeControlBase* &root = pg->egectrl_root;
    pg->skip_timer_mark = true;
    //LeaveCriticalSection(&pg->cs_callbackmessage);
    double delay_time = 600000.0/fps;
    double dw = get_highfeq_time_ls(pg)*60.0;
    int nloop = 0;

    if (pg->delay_fps_dwLast == 0) {
        pg->delay_fps_dwLast = get_highfeq_time_ls(pg)*60.0;
    }
    if (pg->delay_fps_dwLast + 60000 > dw) {
        dw = pg->delay_fps_dwLast;
    }
    root->draw(NULL);
    for (; nloop>=0; --nloop) {
        int bSleep = 0;
        while (dw + delay_time >= get_highfeq_time_ls(pg)*60.0) {
            Sleep(1);
            bSleep = 1;
        }
        if (bSleep) {
            pg->update_mark_count = 0;
            dealmessage(pg, !nloop);
        } else {
            _GetFPS(-0x100);
        }
        dw = get_highfeq_time_ls(pg)*60.0;
        guiupdate(pg, root);
        if (pg->delay_fps_dwLast + 60000 <= dw || pg->delay_fps_dwLast > dw) {
            pg->delay_fps_dwLast = dw;
        } else {
            pg->delay_fps_dwLast += delay_time;
        }
    }
    //EnterCriticalSection(&pg->cs_callbackmessage);
    pg->skip_timer_mark = false;
    {   //�����������޷����µ���ʱ����
        int l,t,r,b,c;
        getviewport(&l, &t, &r, &b, &c);
        setviewport(l, t, r, b, c);
    }
}

int ShowMouse(int bShow) {
    struct _graph_setting * pg = &graph_setting;
    int ret = pg->mouse_show;
    pg->mouse_show = bShow;
    return ret;
}

int
GetMousePos(int *x, int *y) {
    struct _graph_setting * pg = &graph_setting;
    *x = pg->mouse_last_x;
    *y = pg->mouse_last_y;
    return 0;
}

void
setwritemode(int mode, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    SetROP2(img->m_hDC, mode);
    CONVERT_IMAGE_END;
}

COLORREF
getpixel(int x, int y, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    CONVERT_IMAGE_END;
    x += img->m_vpt.left;
    y += img->m_vpt.top;
    if ((x < 0) || (y < 0) || (x >= img->m_width) || (y >= img->m_height)) {
        return 0;
    }
    COLORREF col = img->m_pBuffer[y * img->m_width + x];
    return RGBTOBGR(col);
}

void
putpixel(int x, int y, COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    x += img->m_vpt.left;
    y += img->m_vpt.top;
    if ((x < 0) || (y < 0) || (x >= img->m_vpt.right) || (y >= img->m_vpt.bottom)) {
        ;
    } else {
        img->m_pBuffer[y * img->m_width + x] = RGBTOBGR(color);
    }
    CONVERT_IMAGE_END;
}

void
putpixels(int nPoint, int* pPoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    int x, y, c;
    PDWORD pb = &img->m_pBuffer[img->m_vpt.top * img->m_width + img->m_vpt.left];
    int w = img->m_vpt.right - img->m_vpt.left, h = img->m_vpt.bottom - img->m_vpt.top;
    int tw = img->m_width;
    for (int n=0; n<nPoint; ++n, pPoints += 3) {
        x = pPoints[0], y = pPoints[1], c = pPoints[2];
        if ((x < 0) || (y < 0) || (x >= w) || (y >= h)) {
            ;
        } else {
            pb[y * tw + x] = RGBTOBGR(c);
        }
    }
    CONVERT_IMAGE_END;
}

void
putpixels_f(int nPoint, int* pPoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    int c;
    int tw = img->m_width;
    for (int n=0; n<nPoint; ++n, pPoints += 3) {
        c = pPoints[2];
        img->m_pBuffer[pPoints[1] * tw + pPoints[0]] = RGBTOBGR(c);
    }
    CONVERT_IMAGE_END;
}

COLORREF
getpixel_f(int x, int y, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_F_CONST(pimg);
    COLORREF col = img->m_pBuffer[y * img->m_width + x];
    return RGBTOBGR(col);
}

void
putpixel_f(int x, int y, COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_F(pimg);
    img->m_pBuffer[y * img->m_width + x] = RGBTOBGR(color);
}

void
moveto(int x, int y, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    MoveToEx(img->m_hDC, x, y, NULL);
    CONVERT_IMAGE_END;
}

void
moverel(int dx, int dy, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    POINT pt;
    GetCurrentPositionEx(img->m_hDC, &pt);
    dx += pt.x;
    dy += pt.y;
    MoveToEx(img->m_hDC, dx, dy, NULL);
    CONVERT_IMAGE_END;
}

void
line(int x1, int y1, int x2, int y2, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    MoveToEx(img->m_hDC, x1, y1, NULL);
    LineTo(img->m_hDC, x2, y2);
    CONVERT_IMAGE_END;
}

void
linerel(int dx, int dy, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    POINT pt;
    GetCurrentPositionEx(img->m_hDC, &pt);
    dx += pt.x;
    dy += pt.y;
    LineTo(img->m_hDC, dx, dy);
    CONVERT_IMAGE_END;
}

void
lineto(int x, int y, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    LineTo(img->m_hDC, x, y);
    CONVERT_IMAGE_END;
}

/* private function */
static
void
line_base(float x1, float y1, float x2, float y2, PIMAGE img) {
    int bswap = 2;
    COLORREF col = getcolor(img);
    COLORREF endp = 0;
    COLORREF* pBuffer = (COLORREF*)img->m_pBuffer;
    int rw = img->m_width;
    if (x1 > x2) {
        float ft;
        SWAP(x1, x2, ft);
        SWAP(y1, y2, ft);
        if (bswap) bswap ^= 3;
    }
    if (x2 < img->m_vpt.left) return ;
    if (x1 > img->m_vpt.right) return ;
    if (x1 < img->m_vpt.left) {
        if (x2 - x1 < FLOAT_EPS) return;
        float d = (x2 - img->m_vpt.left) / (x2 - x1);
        y1 = (y1 - y2) * d + y2;
        x1 = (float)img->m_vpt.left;
        if (bswap == 1) bswap = 0;
    }
    if (x2 > img->m_vpt.right) {
        if (x2 - x1 < FLOAT_EPS) return;
        float d = (img->m_vpt.right - x1) / (x2 - x1);
        y2 = (y2 - y1) * d + y1;
        x2 = (float)img->m_vpt.right;
        if (bswap == 2) bswap = 0;
    }
    if (y1 > y2) {
        float ft;
        SWAP(x1, x2, ft);
        SWAP(y1, y2, ft);
        if (bswap) bswap ^= 3;
    }
    if (y2 < img->m_vpt.top) return ;
    if (y1 > img->m_vpt.bottom) return ;
    if (y1 < img->m_vpt.top) {
        if (y2 - y1 < FLOAT_EPS) return;
        float d = (y2 - img->m_vpt.top) / (y2 - y1);
        x1 = (x1 - x2) * d + x2;
        y1 = (float)img->m_vpt.top;
        if (bswap == 1) bswap = 0;
    }
    if (y2 > img->m_vpt.bottom) {
        if (y2 - y1 < FLOAT_EPS) return;
        float d = (img->m_vpt.bottom - y1) / (y2 - y1);
        x2 = (x2 - x1) * d + x1;
        y2 = (float)img->m_vpt.bottom;
        if (bswap == 2) bswap = 0;
    }
    if (bswap) {
        if (bswap == 1)     {
            endp = pBuffer[(int)y1 * rw + (int)x1];
        } else {
            endp = pBuffer[(int)y2 * rw + (int)x2];
        }
    }
    if (y2 - y1 > fabs(x2 - x1)) {
        int y = (int)(y1 + 0.9f);
        int ye = (int)(y2);
        float x, dx;
        if (y < y1) ++y;
        dx = (x2 - x1) / (y2 - y1);
        x = (y - y1) * dx + x1 + 0.5f;
        if (ye >= img->m_vpt.bottom) ye = img->m_vpt.bottom - 1;
        if (ye < y2) bswap = 0;
        for (; y <= ye; ++y, x += dx) {
            pBuffer[y * rw + (int)x] = col;
        }
    } else {
        if (x1 > x2) {
            float ft;
            SWAP(x1, x2, ft);
            SWAP(y1, y2, ft);
            if (bswap) bswap ^= 3;
        }
        int x = (int)(x1 + 0.9f);
        int xe = (int)(x2);
        float y, dy;
        if (x < x1) ++x;
        dy = (y2 - y1) / (x2 - x1);
        y = (x - x1) * dy + y1 + 0.5f;
        if (xe >= img->m_vpt.right) xe = img->m_vpt.right - 1;
        if (xe < x2) bswap = 0;
        for (; x <= xe; ++x, y += dy) {
            pBuffer[(int)y * rw + x] = col;
        }
    }
    if (bswap) {
        if (bswap == 1) {
            pBuffer[(int)y1 * rw + (int)x1] = endp;
        } else {
            pBuffer[(int)y2 * rw + (int)x2] = endp;
        }
    }
}

void
lineto_f(float x, float y, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    POINT pt;
    GetCurrentPositionEx(img->m_hDC, &pt);
    line_base((float)pt.x, (float)pt.y, x, y, img);
    CONVERT_IMAGE_END;
}

void
linerel_f(float dx, float dy, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    POINT pt;
    GetCurrentPositionEx(img->m_hDC, &pt);
    line_base((float)pt.x, (float)pt.y, (float)pt.x + dx, (float)pt.y + dy, img);
    CONVERT_IMAGE_END;
}

void
line_f(float x1, float y1, float x2, float y2, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    line_base(x1, y1, x2, y2, img);
    CONVERT_IMAGE_END;
}

/*private function*/
static
int
saveBrush(PIMAGE img, int save) { //�˺�������ǰ���Ѿ���Lock
    struct _graph_setting * pg = &graph_setting;
    if (save) {
        LOGBRUSH lbr = {0};

        lbr.lbColor = 0;
        lbr.lbStyle = BS_NULL;
        pg->savebrush_hbr = CreateBrushIndirect(&lbr);
        if (pg->savebrush_hbr) {
            pg->savebrush_hbr = (HBRUSH)SelectObject(img->m_hDC, pg->savebrush_hbr);
            return 1;
        }
    } else {
        if (pg->savebrush_hbr) {
            pg->savebrush_hbr = (HBRUSH)SelectObject(img->m_hDC, pg->savebrush_hbr);
            DeleteObject(pg->savebrush_hbr);
            pg->savebrush_hbr = NULL;
        }
    }
    return 0;
}

void rectangle(int left, int top, int right, int bottom, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (saveBrush(img, 1)) {
        Rectangle(img->m_hDC, left, top, right, bottom);
        saveBrush(img, 0);
    }
    CONVERT_IMAGE_END;
}

COLORREF
getcolor(PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);

    if (img && img->m_hDC) {
        CONVERT_IMAGE_END;
        return img->m_color;
        /*
        HPEN hpen_c = (HPEN)GetCurrentObject(img->m_hDC, OBJ_PEN);
        LOGPEN logPen;
        GetObject(hpen_c, sizeof(logPen), &logPen);
        CONVERT_IMAGE_END;
        return logPen.lopnColor;
        // */
    }
    CONVERT_IMAGE_END;
    return 0xFFFFFFFF;
}

void
setcolor(COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        LOGPEN lPen;
        HPEN hpen;

        img->m_color = color;
        lPen.lopnColor   = color;
        lPen.lopnStyle   = img->m_linestyle.linestyle;
        lPen.lopnWidth.x = img->m_linestyle.thickness;

        SetTextColor(img->m_hDC, color);
        if (lPen.lopnStyle == PS_USERSTYLE) {
            DWORD style[20] = {0};
            LOGBRUSH lbr;
            unsigned short upattern = img->m_linestyle.upattern;
            int n, bn = 0, len = 1, st = 0;
            lbr.lbColor = lPen.lopnColor;
            lbr.lbStyle = BS_SOLID;
            lbr.lbHatch = 0;
            st = upattern & 1;
            for (n = 1; n < 16; n++) {
                if (upattern & (1<<n)) {
                    if (st == 0) {
                        st = 1;
                        style[bn++] = len;
                        len = 1;
                    } else {
                        len++;
                    }
                } else {
                    if (st == 0) {
                        len++;
                    } else {
                        st = 0;
                        style[bn++] = len;
                        len = 1;
                    }
                }
            }
            hpen = ExtCreatePen(PS_GEOMETRIC, img->m_linestyle.thickness, &lbr, bn, style);
        } else {
            hpen = CreatePenIndirect(&lPen);
        }
        if (hpen) {
            DeleteObject(SelectObject(img->m_hDC, hpen));
        }
    }
    CONVERT_IMAGE_END;
}

void
setfillcolor(COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    LOGBRUSH lbr = {0};
    lbr.lbColor = color;
    lbr.lbHatch = BS_SOLID;
    img->m_fillcolor = color;
    HBRUSH hbr = CreateBrushIndirect(&lbr);
    if (hbr) {
        DeleteObject(SelectObject(img->m_hDC, hbr));
    }
    CONVERT_IMAGE_END;
}

COLORREF
getfillcolor(PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);

    if (img && img->m_hDC) {
        CONVERT_IMAGE_END;
        return img->m_fillcolor;
    }
    CONVERT_IMAGE_END;
    return 0xFFFFFFFF;
}

COLORREF
getbkcolor(PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);

    CONVERT_IMAGE_END;
    if (img) {
        return img->m_bk_color;
    }
    return 0xFFFFFFFF;
}

void
setbkcolor(COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        PDWORD p = img->m_pBuffer;
        int size = img->m_width * img->m_height;
        COLORREF col = img->m_bk_color;
        img->m_bk_color = color;
        SetBkColor(img->m_hDC, color);
        color = RGBTOBGR(color);
        col   = RGBTOBGR(col);
        for (int n = 0; n < size; n++, p++) {
            if (*p == col) {
                *p = color;
            }
        }
    }
    CONVERT_IMAGE_END;
}
void
setbkcolor_f(COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        img->m_bk_color = color;
        SetBkColor(img->m_hDC, color);
    }
    CONVERT_IMAGE_END;
}

void setfontbkcolor(COLORREF color, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        SetBkColor(img->m_hDC, color);
    }
    CONVERT_IMAGE_END;
}

void
setbkmode(int iBkMode, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img && img->m_hDC) {
        SetBkMode(img->m_hDC, iBkMode);
    }
    CONVERT_IMAGE_END;
}

PIMAGE gettarget() {
    struct _graph_setting * pg = &graph_setting;
    return pg->imgtarget_set;
}
int settarget(PIMAGE pbuf) {
    struct _graph_setting * pg = &graph_setting;
    pg->imgtarget_set = pbuf;
    if (pbuf == NULL) {
        pg->imgtarget = pg->img_page[graph_setting.active_page];
    } else {
        pg->imgtarget = pbuf;
    }
    return 0;
}

void
cleardevice(PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        RECT rect = {
            0,
            0,
            img->m_width,
            img->m_height
        };
        //HBRUSH hbr_c = (HBRUSH)GetCurrentObject(img->m_hDC, OBJ_BRUSH);
        //LOGBRUSH logBrush;
        //GetObject(hbr_c, sizeof(logBrush), &logBrush);
        HBRUSH hbr = CreateSolidBrush(img->m_bk_color);
        FillRect(img->m_hDC, &rect, hbr);
        DeleteObject(hbr);
    }
    CONVERT_IMAGE_END;
}

void
arc(int x, int y, int stangle, int endangle, int radius, PIMAGE pimg) {
    ellipse(x, y, stangle, endangle, radius, radius, pimg);
}

void
circle(int x, int y, int radius, PIMAGE pimg) {
    ellipse(x, y, 0, 360, radius, radius, pimg);
}

void
ellipse(int x, int y, int stangle, int endangle, int xradius, int yradius, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    double sr = stangle/180.0*PI, er = endangle/180.0*PI;

    if (img) {
        Arc(img->m_hDC,
        x-xradius, y-yradius,
        x+xradius, y+yradius,
        (int)(x + xradius*cos(sr)),
        (int)(y - yradius*sin(sr)),
        (int)(x + xradius*cos(er)),
        (int)(y - yradius*sin(er))
        );
    }
    CONVERT_IMAGE_END;
}

void
pieslice(int x, int y, int stangle, int endangle, int radius, PIMAGE pimg) {
    sector(x, y, stangle, endangle, radius, radius, pimg);
}

void
sector(int x, int y, int stangle, int endangle, int xradius, int yradius, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    double sr = stangle/180.0*PI, er = endangle/180.0*PI;
    if (img) {
        Pie(img->m_hDC,
            x-xradius, y-yradius,
            x+xradius, y+yradius,
            (int)(x + xradius*cos(sr)), (int)(y - yradius*sin(sr)),
            (int)(x + xradius*cos(er)), (int)(y - yradius*sin(er))
            );
    }
    CONVERT_IMAGE_END;
}

void
fillellipse(int x, int y, int xradius, int yradius, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (img) {
        Ellipse(
            img->m_hDC,
            x-xradius, y-yradius,
            x+xradius, y+yradius
            );
    }
    CONVERT_IMAGE_END;
}

void
bar(int left, int top, int right, int bottom, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    RECT rect = {left, top, right, bottom};
    HBRUSH hbr_last = (HBRUSH)GetCurrentObject(img->m_hDC, OBJ_BRUSH); //(HBRUSH)SelectObject(pg->g_hdc, hbr);

    if (img) {
        FillRect(img->m_hDC, &rect, hbr_last);
    }
    CONVERT_IMAGE_END;
}

void
bar3d(int x1, int y1, int x2, int y2, int depth, int topflag, PIMAGE pimg) {
    --x2; --y2;
    {
        int pt[20] = {
            x2, y2,
            x2, y1,
            x1, y1,
            x1, y2,
            x2, y2,
            x2+depth, y2-depth,
            x2+depth, y1-depth,
            x1+depth, y1-depth,
            x1, y1,
        };

        bar(x1, y1, x2, y2, pimg);
        if (topflag) {
            drawpoly(9, pt, pimg);
            line(x2, y1, x2+depth, y1-depth, pimg);
        } else {
            drawpoly(7, pt, pimg);
        }
    }
}

void
drawpoly(int numpoints, const int *polypoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (img) {
        Polyline(img->m_hDC, (POINT*)polypoints, numpoints);
    }
    CONVERT_IMAGE_END;
}

void
drawbezier(int numpoints, const int *polypoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (img) {
        if (numpoints % 3 != 1) {
            numpoints = numpoints - (numpoints + 2) % 3;
        }
        PolyBezier(img->m_hDC, (POINT*)polypoints, numpoints);
    }
    CONVERT_IMAGE_END;
}

void
drawlines(int numlines, const int *polypoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (img) {
        DWORD* pl = (DWORD*) malloc(sizeof(DWORD) * numlines);
        for (int i = 0; i < numlines; ++i) pl[i] = 2;
        PolyPolyline(img->m_hDC, (POINT*)polypoints, pl, numlines);
        free(pl);
    }
    CONVERT_IMAGE_END;
}

void
fillpoly(int numpoints, const int *polypoints, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        Polygon(img->m_hDC, (POINT*)polypoints, numpoints);
    }
    CONVERT_IMAGE_END;
}

void
floodfill(int x, int y, int border, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);
    if (img) {
        FloodFill(img->m_hDC, x, y, border);
    }
    CONVERT_IMAGE_END;
}

/* private function */
static
unsigned int
private_gettextmode(PIMAGE img) {
    UINT fMode = TA_NOUPDATECP; //TA_UPDATECP;
    if (img->m_texttype.horiz == RIGHT_TEXT) {
        fMode |= TA_RIGHT;
    } else if (img->m_texttype.horiz == CENTER_TEXT) {
        fMode |= TA_CENTER;
    } else {
        fMode |= TA_LEFT;
    }
    if (img->m_texttype.vert == BOTTOM_TEXT) {
        fMode |= TA_BOTTOM;
    } else {
        fMode |= TA_TOP;
    }
    return fMode;
}

/* private function */
static
void
private_textout (PIMAGE img, LPCSTR textstring, int x, int y, int horiz, int vert) {
    if (horiz >= 0 && vert >= 0) {
        UINT fMode = TA_NOUPDATECP; //TA_UPDATECP;
        img->m_texttype.horiz = horiz;
        img->m_texttype.vert = vert;
        if (img->m_texttype.horiz == RIGHT_TEXT) {
            fMode |= TA_RIGHT;
        } else if (img->m_texttype.horiz == CENTER_TEXT) {
            fMode |= TA_CENTER;
        } else {
            fMode |= TA_LEFT;
        }
        if (img->m_texttype.vert == BOTTOM_TEXT) {
            fMode |= TA_BOTTOM;
        } else {
            fMode |= TA_TOP;
        }
        SetTextAlign(img->m_hDC, fMode);
    } else {
        SetTextAlign(img->m_hDC, private_gettextmode(img));
    }
    if (textstring) {
        if (img->m_texttype.vert == CENTER_TEXT) {
            y -= textheight(textstring, img)/2;
        }
        TextOutA(img->m_hDC, x, y, textstring, (int)strlen(textstring));
    }
}

/* private function */
static
void
private_textout (PIMAGE img, LPCWSTR textstring, int x, int y, int horiz, int vert) {
    if (horiz >= 0 && vert >= 0) {
        UINT fMode = TA_NOUPDATECP; //TA_UPDATECP;
        img->m_texttype.horiz = horiz;
        img->m_texttype.vert = vert;
        if (img->m_texttype.horiz == RIGHT_TEXT) {
            fMode |= TA_RIGHT;
        } else if (img->m_texttype.horiz == CENTER_TEXT) {
            fMode |= TA_CENTER;
        } else {
            fMode |= TA_LEFT;
        }
        if (img->m_texttype.vert == BOTTOM_TEXT) {
            fMode |= TA_BOTTOM;
        } else {
            fMode |= TA_TOP;
        }
        SetTextAlign(img->m_hDC, fMode);
    } else {
        SetTextAlign(img->m_hDC, private_gettextmode(img));
    }
    if (textstring) {
        if (img->m_texttype.vert == CENTER_TEXT) {
            y -= textheight(textstring, img)/2;
        }
        TextOutW(img->m_hDC, x, y, textstring, (int)lstrlenW(textstring));
    }
}

void
outtext(LPCSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        POINT pt;
        GetCurrentPositionEx(img->m_hDC, &pt);
        private_textout(img, textstring, pt.x, pt.y, -1, -1);
    }
    CONVERT_IMAGE_END;
}

void
outtext(LPCWSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        POINT pt;
        GetCurrentPositionEx(img->m_hDC, &pt);
        private_textout(img, textstring, pt.x, pt.y, -1, -1);
    }
    CONVERT_IMAGE_END;
}

void
outtext(CHAR c, PIMAGE pimg) {
    CHAR str[10] = {c};
    outtext(str, pimg);
}

void
outtext(WCHAR c, PIMAGE pimg) {
    WCHAR str[10] = {c};
    outtext(str, pimg);
}

void
outtextxy(int x, int y, LPCSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        private_textout(img, textstring, x, y, -1, -1);
    }
    CONVERT_IMAGE_END;
}

void
outtextxy(int x, int y, LPCWSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        private_textout(img, textstring, x, y, -1, -1);
    }
    CONVERT_IMAGE_END;
}

void
outtextxy(int x, int y, CHAR c, PIMAGE pimg) {
    CHAR str[10] = {c};
    outtextxy(x, y, str, pimg);
}

void
outtextxy(int x, int y, WCHAR c, PIMAGE pimg) {
    WCHAR str[10] = {c};
    outtextxy(x, y, str, pimg);
}

void
outtextrect(int x, int y, int w, int h, LPCSTR  textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        unsigned int fmode = private_gettextmode(img);
        RECT rect = {x, y, x+w, y+h};
        DrawTextA(img->m_hDC, textstring, -1, &rect, fmode|DT_NOPREFIX|DT_WORDBREAK|DT_EDITCONTROL|DT_EXPANDTABS);
    }

    CONVERT_IMAGE_END;
}

void
outtextrect(int x, int y, int w, int h, LPCWSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img) {
        unsigned int fmode = private_gettextmode(img);
        RECT rect = {x, y, x+w, y+h};
        DrawTextW(img->m_hDC, textstring, -1, &rect, fmode|DT_NOPREFIX|DT_WORDBREAK|DT_EDITCONTROL|DT_EXPANDTABS);
    }

    CONVERT_IMAGE_END;
}

int
textwidth(LPCSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        SIZE sz;
        GetTextExtentPoint32A(img->m_hDC, textstring, (int)strlen(textstring), &sz);
        CONVERT_IMAGE_END;
        return sz.cx;
    }
    CONVERT_IMAGE_END;
    return 0;
}

int
textwidth(LPCWSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        SIZE sz;
        GetTextExtentPoint32W(img->m_hDC, textstring, (int)lstrlenW(textstring), &sz);
        CONVERT_IMAGE_END;
        return sz.cx;
    }
    CONVERT_IMAGE_END;
    return 0;
}

int
textwidth(CHAR c, PIMAGE pimg) {
    CHAR str[2] = {c};
    return textwidth(str, pimg);
}

int
textwidth(WCHAR c, PIMAGE pimg) {
    WCHAR str[2] = {c};
    return textwidth(str, pimg);
}

int
textheight(LPCSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        SIZE sz;
        GetTextExtentPoint32A(img->m_hDC, textstring, (int)strlen(textstring), &sz);
        CONVERT_IMAGE_END;
        return sz.cy;
    }
    CONVERT_IMAGE_END;
    return 0;
}

int
textheight(LPCWSTR textstring, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        SIZE sz;
        GetTextExtentPoint32W(img->m_hDC, textstring, (int)lstrlenW(textstring), &sz);
        CONVERT_IMAGE_END;
        return sz.cy;
    }
    CONVERT_IMAGE_END;
    return 0;
}

int
textheight(CHAR c, PIMAGE pimg) {
    CHAR str[2] = {c};
    return textheight(str, pimg);
}

int
textheight(WCHAR c, PIMAGE pimg) {
    WCHAR str[2] = {c};
    return textheight(str, pimg);
}

void
settextjustify(int horiz, int vert, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        img->m_texttype.horiz = horiz;
        img->m_texttype.vert = vert;
    }
    CONVERT_IMAGE_END;
}

void
getlinestyle(int *plinestyle, unsigned short *pupattern, int *pthickness, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (plinestyle) {
        *plinestyle = img->m_linestyle.linestyle;
    }
    if (pupattern) {
        *pupattern = img->m_linestyle.upattern;
    }
    if (pthickness) {
        *pthickness = img->m_linestyle.thickness;
    }
    CONVERT_IMAGE_END;
}

void
setlinestyle(int linestyle, unsigned short upattern, int thickness, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    LOGPEN lpen = {0};
    lpen.lopnColor = getcolor(pimg);
    img->m_linestyle.thickness = thickness;
    img->m_linestyle.linestyle = linestyle;
    img->m_linestyle.upattern = upattern;

    lpen.lopnWidth.x = thickness;
    lpen.lopnStyle   = linestyle;

    HPEN hpen;
    if (linestyle == PS_USERSTYLE) {
        DWORD style[20] = {0};
        LOGBRUSH lbr;
        int n, bn = 0, len = 1, st = 0;
        lbr.lbColor = lpen.lopnColor;
        lbr.lbStyle = BS_SOLID;
        lbr.lbHatch = 0;
        st = upattern & 1;
        for (n = 1; n < 16; n++) {
            if (upattern & (1<<n)) {
                if (st == 0) {
                    st = 1;
                    style[bn++] = len;
                    len = 1;
                } else {
                    len++;
                }
            } else {
                if (st == 0) {
                    len++;
                } else {
                    st = 0;
                    style[bn++] = len;
                    len = 1;
                }
            }
        }
        hpen = ExtCreatePen(PS_GEOMETRIC, thickness, &lbr, bn, style);
    } else {
        hpen = CreatePenIndirect(&lpen);
    }
    if (hpen) {
        DeleteObject(SelectObject(img->m_hDC, hpen));
    }
    CONVERT_IMAGE_END;
}

void
setfillstyle(COLORREF color, int pattern, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    LOGBRUSH lbr = {0};
    lbr.lbColor = color;
    img->m_fillcolor = color;
    //SetBkColor(img->m_hDC, color);
    if (pattern < SOLID_FILL) {
        lbr.lbHatch = BS_NULL;
    } else if (pattern == SOLID_FILL) {
        lbr.lbHatch = BS_SOLID;
    } else if (pattern < USER_FILL) { // dose not finish
        int hatchmap[] = {
            HS_VERTICAL,
            HS_BDIAGONAL,
            HS_BDIAGONAL,
            HS_FDIAGONAL,
            HS_FDIAGONAL,
            HS_CROSS,
            HS_DIAGCROSS,
            HS_VERTICAL,
            HS_DIAGCROSS,
            HS_DIAGCROSS
        };
        lbr.lbStyle = BS_HATCHED;
        lbr.lbHatch = hatchmap[pattern - 2];
    } else {
        lbr.lbHatch = BS_SOLID;
    }
    HBRUSH hbr = CreateBrushIndirect(&lbr);
    if (hbr) {
        DeleteObject(SelectObject(img->m_hDC, hbr));
    }
    CONVERT_IMAGE_END;
}

void
setfont(
        int nHeight,
        int nWidth,
        LPCSTR lpszFace,
        int nEscapement,
        int nOrientation,
        int nWeight,
        int bItalic,
        int bUnderline,
        int bStrikeOut,
        BYTE fbCharSet,
        BYTE fbOutPrecision,
        BYTE fbClipPrecision,
        BYTE fbQuality,
        BYTE fbPitchAndFamily,
        PIMAGE pimg)
{
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTA lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = nEscapement;
        lf.lfOrientation    = nOrientation;
        lf.lfWeight         = nWeight;
        lf.lfItalic         = (bItalic != 0);
        lf.lfUnderline      = (bUnderline != 0);
        lf.lfStrikeOut      = (bStrikeOut != 0);
        lf.lfCharSet        = fbCharSet;
        lf.lfOutPrecision   = fbOutPrecision;
        lf.lfClipPrecision  = fbClipPrecision;
        lf.lfQuality        = fbQuality;
        lf.lfPitchAndFamily = fbPitchAndFamily;
        lstrcpyA(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectA(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(
        int nHeight,
        int nWidth,
        LPCWSTR lpszFace,
        int nEscapement,
        int nOrientation,
        int nWeight,
        int bItalic,
        int bUnderline,
        int bStrikeOut,
        BYTE fbCharSet,
        BYTE fbOutPrecision,
        BYTE fbClipPrecision,
        BYTE fbQuality,
        BYTE fbPitchAndFamily,
        PIMAGE pimg)
{
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTW lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = nEscapement;
        lf.lfOrientation    = nOrientation;
        lf.lfWeight         = nWeight;
        lf.lfItalic         = (bItalic != 0);
        lf.lfUnderline      = (bUnderline != 0);
        lf.lfStrikeOut      = (bStrikeOut != 0);
        lf.lfCharSet        = fbCharSet;
        lf.lfOutPrecision   = fbOutPrecision;
        lf.lfClipPrecision  = fbClipPrecision;
        lf.lfQuality        = fbQuality;
        lf.lfPitchAndFamily = fbPitchAndFamily;
        lstrcpyW(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectW(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(
        int nHeight,
        int nWidth,
        LPCSTR lpszFace,
        int nEscapement,
        int nOrientation,
        int nWeight,
        int bItalic,
        int bUnderline,
        int bStrikeOut,
        PIMAGE pimg)
{
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTA lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = nEscapement;
        lf.lfOrientation    = nOrientation;
        lf.lfWeight         = nWeight;
        lf.lfItalic         = (bItalic != 0);
        lf.lfUnderline      = (bUnderline != 0);
        lf.lfStrikeOut      = (bStrikeOut != 0);
        lf.lfCharSet        = DEFAULT_CHARSET;
        lf.lfOutPrecision   = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision  = CLIP_DEFAULT_PRECIS;
        lf.lfQuality        = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = DEFAULT_PITCH;
        lstrcpyA(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectA(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(
        int nHeight,
        int nWidth,
        LPCWSTR lpszFace,
        int nEscapement,
        int nOrientation,
        int nWeight,
        int bItalic,
        int bUnderline,
        int bStrikeOut,
        PIMAGE pimg)
{
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTW lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = nEscapement;
        lf.lfOrientation    = nOrientation;
        lf.lfWeight         = nWeight;
        lf.lfItalic         = (bItalic != 0);
        lf.lfUnderline      = (bUnderline != 0);
        lf.lfStrikeOut      = (bStrikeOut != 0);
        lf.lfCharSet        = DEFAULT_CHARSET;
        lf.lfOutPrecision   = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision  = CLIP_DEFAULT_PRECIS;
        lf.lfQuality        = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = DEFAULT_PITCH;
        lstrcpyW(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectW(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(int nHeight, int nWidth, LPCSTR lpszFace, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTA lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = 0;
        lf.lfOrientation    = 0;
        lf.lfWeight         = FW_DONTCARE;
        lf.lfItalic         = 0;
        lf.lfUnderline      = 0;
        lf.lfStrikeOut      = 0;
        lf.lfCharSet        = DEFAULT_CHARSET;
        lf.lfOutPrecision   = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision  = CLIP_DEFAULT_PRECIS;
        lf.lfQuality        = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = DEFAULT_PITCH;
        lstrcpyA(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectA(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(int nHeight, int nWidth, LPCWSTR lpszFace, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        LOGFONTW lf = {0};
        lf.lfHeight         = nHeight;
        lf.lfWidth          = nWidth;
        lf.lfEscapement     = 0;
        lf.lfOrientation    = 0;
        lf.lfWeight         = FW_DONTCARE;
        lf.lfItalic         = 0;
        lf.lfUnderline      = 0;
        lf.lfStrikeOut      = 0;
        lf.lfCharSet        = DEFAULT_CHARSET;
        lf.lfOutPrecision   = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision  = CLIP_DEFAULT_PRECIS;
        lf.lfQuality        = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = DEFAULT_PITCH;
        lstrcpyW(lf.lfFaceName, lpszFace);
        HFONT hfont = CreateFontIndirectW(&lf);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(const LOGFONTA *font, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        HFONT hfont = CreateFontIndirectA(font);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
setfont(const LOGFONTW *font, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        HFONT hfont = CreateFontIndirectW(font);
        DeleteObject(SelectObject(img->m_hDC, hfont));
    }
    CONVERT_IMAGE_END;
}

void
getfont(LOGFONTA *font, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        HFONT hf = (HFONT)GetCurrentObject(img->m_hDC, OBJ_FONT);
        GetObjectA(hf, sizeof(LOGFONTA), font);
    }
    CONVERT_IMAGE_END;
}

void
getfont(LOGFONTW *font, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if (img) {
        HFONT hf = (HFONT)GetCurrentObject(img->m_hDC, OBJ_FONT);
        GetObjectW(hf, sizeof(LOGFONTA), font);
    }
    CONVERT_IMAGE_END;
}


void
WindowLock() {
    struct _graph_setting * pg = &graph_setting;
    if (pg->lock_window) {
        ;
    } else {
        KillTimer(pg->hwnd, RENDER_TIMER_ID);
        pg->timer_stop_mark = true;
        PostMessageW(pg->hwnd, WM_TIMER, RENDER_TIMER_ID, 0);
        pg->lock_window = true;
        while (pg->timer_stop_mark) {
            Sleep(1);
        }
    }
}

void
WindowFlush() {
    struct _graph_setting * pg = &graph_setting;
    WindowFlush(0, 0, pg->dc_w, pg->dc_h);
}

void
WindowFlush(int left, int top, int right, int bottom) {
    delay_ms(0);
}

void
WindowUnlock() {
    struct _graph_setting * pg = &graph_setting;
    WindowUnlock(0, 0, pg->dc_w, pg->dc_h);
}

void
WindowUnlock(int left, int top, int right, int bottom) {
    struct _graph_setting * pg = &graph_setting;
    WindowFlush(left, top, right, bottom);
    SetTimer(pg->hwnd, RENDER_TIMER_ID, 0, NULL);
    pg->skip_timer_mark = false;
    pg->lock_window = false;
}

void
setactivepage(int page) {
    struct _graph_setting * pg = &graph_setting;
    pg->active_page = page;
    if (pg->img_page[page] == NULL) {
        pg->img_page[page] = new IMAGE;
        pg->img_page[page]->createimage(pg->dc_w, pg->dc_h);
        pg->dc = pg->img_page[page]->m_hDC;
    }
}

void
setvisualpage(int page) {
    struct _graph_setting * pg = &graph_setting;
    pg->visual_page = page;
    if (pg->img_page[page] == NULL) {
        pg->img_page[page] = new IMAGE;
        pg->img_page[page]->createimage(pg->dc_w, pg->dc_h);
    }
    pg->update_mark_count = 0;
}

void
swappage() {
    struct _graph_setting * pg = &graph_setting;
    EnterCriticalSection(&pg->cs_render);
    setvisualpage(pg->active_page);
    setactivepage(1 - pg->active_page);
    LeaveCriticalSection(&pg->cs_render);
}

void
window_getviewport(struct viewporttype * viewport) {
    struct _graph_setting * pg = &graph_setting;
    viewport->left   = pg->base_x;
    viewport->top    = pg->base_y;
    viewport->right  = pg->base_w + pg->base_x;
    viewport->bottom = pg->base_h + pg->base_y;
}

void
window_getviewport(int* left, int* top, int* right, int* bottom) {
    struct _graph_setting * pg = &graph_setting;
    if (left)   *left   = pg->base_x;
    if (top)    *top    = pg->base_y;
    if (right)  *right  = pg->base_w + pg->base_x;
    if (bottom) *bottom = pg->base_h + pg->base_y;
}

void
window_setviewport(int left, int top, int right, int bottom) {
    struct _graph_setting * pg = &graph_setting;
    int same_xy = 0, same_wh = 0;
    if (pg->base_x == left && pg->base_y == top) {
        same_xy = 1;
    }
    if (pg->base_w == bottom - top && pg->base_h == right - left) {
        same_wh = 1;
    }
    pg->base_x = left;
    pg->base_y = top;
    pg->base_w = right - left;
    pg->base_h = bottom - top;
    if (same_xy == 0 || same_wh == 0) {
        graph_setting.update_mark_count -= 1;
    }
    /*�������ڴ�С*/
    if (same_wh == 0) {
        RECT rect, crect;
        int dw, dh;
        GetClientRect(pg->hwnd, &crect);
        GetWindowRect(pg->hwnd, &rect);
        dw = pg->base_w - crect.right;
        dh = pg->base_h - crect.bottom;
        {
            HWND hwnd = GetParent(pg->hwnd);
            if (hwnd) {
                POINT pt = {0, 0};
                ClientToScreen(hwnd, &pt);
                rect.left   -= pt.x;
                rect.top    -= pt.y;
                rect.right  -= pt.x;
                rect.bottom -= pt.y;
            }

            MoveWindow(
                pg->hwnd,
                rect.left,
                rect.top,
                rect.right+dw-rect.left,
                rect.bottom+dh-rect.top,
                TRUE);
        }
    }
}

void
getviewport(int *pleft, int *ptop, int *pright, int *pbottom, int *pclip, PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE_CONST(pimg);
    if(pleft)   *pleft  = img->m_vpt.left;
    if (ptop)   *ptop   = img->m_vpt.top;
    if (pright) *pright = img->m_vpt.right;
    if (pbottom)*pbottom= img->m_vpt.bottom;
    if (pclip)  *pclip  = img->m_vpt.clipflag;
    CONVERT_IMAGE_END;
}

void
setviewport(int left, int top, int right, int bottom, int clip, PIMAGE pimg) {
    //struct _graph_setting * pg = &graph_setting;

    PIMAGE img = CONVERT_IMAGE(pimg);

    SetViewportOrgEx(img->m_hDC, 0, 0, NULL);

    img->m_vpt.left     = left;
    img->m_vpt.top      = top;
    img->m_vpt.right    = right;
    img->m_vpt.bottom   = bottom;
    img->m_vpt.clipflag = clip;

    if (img->m_vpt.left < 0) {
        img->m_vpt.left = 0;
    }
    if (img->m_vpt.top < 0) {
        img->m_vpt.top = 0;
    }
    if (img->m_vpt.right > img->m_width) {
        img->m_vpt.right = img->m_width;
    }
    if (img->m_vpt.bottom > img->m_height) {
        img->m_vpt.bottom = img->m_height;
    }

    HRGN rgn = NULL;
    if (img->m_vpt.clipflag) {
        rgn = CreateRectRgn(
            img->m_vpt.left,
            img->m_vpt.top,
            img->m_vpt.right,
            img->m_vpt.bottom
            );
    } else {
        rgn = CreateRectRgn(
            0,
            0,
            img->m_width,
            img->m_height
            );
    }
    SelectClipRgn(img->m_hDC, rgn);
    DeleteObject(rgn);

    //OffsetViewportOrgEx(img->m_hDC, img->m_vpt.left, img->m_vpt.top, NULL);
    SetViewportOrgEx(img->m_hDC, img->m_vpt.left, img->m_vpt.top, NULL);

    //if (pimg == NULL && pg->lock_window)
    //{
    //    LeaveCriticalSection(&pg->cs_render);
    //}
    CONVERT_IMAGE_END;
}

void
clearviewport(PIMAGE pimg) {
    PIMAGE img = CONVERT_IMAGE(pimg);

    if (img && img->m_hDC) {
        RECT rect = {
            0,
            0,
            img->m_vpt.right - img->m_vpt.left,
            img->m_vpt.bottom - img->m_vpt.top
        };
        HBRUSH hbr_c = (HBRUSH)GetCurrentObject(img->m_hDC, OBJ_BRUSH);
        LOGBRUSH logBrush;
        GetObject(hbr_c, sizeof(logBrush), &logBrush);
        HBRUSH hbr = CreateSolidBrush(logBrush.lbColor);
        FillRect(img->m_hDC, &rect, hbr);
        DeleteObject(hbr);
    }
    CONVERT_IMAGE_END;
}

HWND
GetHWnd() {
    struct _graph_setting * pg = &graph_setting;
    return pg->hwnd;
}

HINSTANCE
GetHInstance() {
    struct _graph_setting * pg = &graph_setting;
    return pg->instance;
}

int
message_addkeyhandler(void* param, LPMSG_KEY_PROC func) {
    struct _graph_setting * pg = &graph_setting;
    pg->callback_key = func;
    pg->callback_key_param = param;
    return grOk;
}

int
message_addmousehandler(void* param, LPMSG_MOUSE_PROC func) {
    struct _graph_setting * pg = &graph_setting;
    pg->callback_mouse = func;
    pg->callback_mouse_param = param;
    return grOk;
}

int
SetCloseHandler(LPCALLBACK_PROC func) {
    struct _graph_setting * pg = &graph_setting;
    pg->callback_close = func;
    return grOk;
}

/* private funcion */
static
void
draw_frame(PIMAGE img, int l, int t, int r, int b, COLORREF lc, COLORREF dc) {
    setcolor(lc, img);
    line(l, b, l, t, img);
    lineto(r, t, img);
    setcolor(dc, img);
    lineto(r, b, img);
    lineto(l, b, img);
}

int
InputBoxGetLine(LPCSTR title, LPCSTR text, LPSTR buf, int len) {
    WCHAR _title[256], _text[256], *_buf = (WCHAR*)malloc(len * 2);
    int ret;
    MultiByteToWideChar(CP_ACP, 0, title, -1, _title, 256);
    MultiByteToWideChar(CP_ACP, 0,  text, -1,  _text, 256);
    buf[0] = 0;
    ret = InputBoxGetLine(_title, _text, _buf, len);
    if (ret) {
        WideCharToMultiByte(CP_ACP, 0, _buf, -1, buf, len, 0, 0);
    }
    free(_buf);
    return ret;
}

int
InputBoxGetLine(LPCWSTR title, LPCWSTR text, LPWSTR buf, int len) {
    struct _graph_setting * pg = &graph_setting;
    IMAGE bg;
    IMAGE window;
    int w = 400, h = 300, x = (getwidth() - w) / 2, y = (getheight() - h) / 2;
    bool b_batchdraw_on = false;
    int ret = 0;
    int n_kbhit;
    bg.getimage(0, 0, getwidth(), getheight());
    window.createimage(w, h);
    buf[0] = 0;

    b_batchdraw_on = pg->lock_window;
    if (!b_batchdraw_on) {
        WindowLock();
    }
    for ( ; (n_kbhit = kbhitEx(0xFFFF)) != -1; ) {
        if (n_kbhit == 0) {
            delay_ms(0);
        }
        putimage(0, 0, &bg);
        {
            setbkcolor(0x80A080, &window);
            draw_frame(&window, 0, 0, w-1, h-1, 0xA0C0A0, 0x507050);
            setfillstyle(0xA00000, SOLID_FILL, &window);
            for (int dy = 1; dy<24; dy++) {
                setcolor(HSLtoRGB(240.0f, 1.0f, 0.5f + float(dy/24.0*0.3)), &window);
                line(1, dy, w-1, dy, &window);
            }
            setcolor(0xFFFFFF, &window);
            setbkmode(TRANSPARENT, &window);
            setfont(18, 0, L"Tahoma", &window);
            outtextxy(3, 3, title, &window);
            setcolor(0x0, &window);
            {
                RECT rect = {30, 32, w-30, 128-3};
                DrawTextW(window.m_hDC, text, -1, &rect, DT_NOPREFIX|DT_LEFT|DT_TOP|TA_NOUPDATECP|DT_WORDBREAK|DT_EDITCONTROL|DT_EXPANDTABS);
            }
            setfillstyle(0xE0E0E0, SOLID_FILL, &window);
            setfont(14, 0, L"Tahoma", &window);
            bar(30, 192, w-30, h-40, &window);
            {
                RECT rect = {30+1, 192+1, w-30-1, h-40-1};
                PWCHAR buffer = (PWCHAR)malloc(len + 4);
                lstrcpyW(buffer, buf);
                lstrcatW(buffer, L"_");
                DrawTextW(window.m_hDC, buffer, -1, &rect, DT_NOPREFIX|DT_LEFT|DT_TOP|TA_NOUPDATECP|DT_WORDBREAK|DT_EDITCONTROL|DT_EXPANDTABS);
                free(buffer);
            }
            draw_frame(&window, 29, 192 - 1, w-30, h-40, 0x909090, 0xFFFFFF);
        }
        putimage(x, y, &window);
        {
            COMPOSITIONFORM cpf = {0};
            struct viewporttype _vpt;
            window_getviewport(&_vpt);
            cpf.dwStyle = CFS_POINT;
            cpf.ptCurrentPos.x = x + (30    ) - _vpt.left;
            cpf.ptCurrentPos.y = y + (h - 40) - _vpt.top ;
            SendMessage(pg->hwnd, WM_IME_CONTROL, IMC_SETSTATUSWINDOWPOS, (LPARAM)&cpf.ptCurrentPos);
        }
        do {
            key_msg ogn_key = getkey();
            int key = ogn_key.key;
            if (key == VK_RETURN && (ogn_key.msg == key_msg_down)) {
                ret = 1;
                goto EXIT;
            } else if (key == VK_ESCAPE && (ogn_key.msg == key_msg_down)) {
                buf[0] = 0;
                goto EXIT;
            } else if (key == VK_BACK && (ogn_key.msg == key_msg_char)) {
                int n = lstrlenW(buf);
                if (n > 0) {
                    buf[n-1] = 0;
                }
            } else if (ogn_key.msg == key_msg_char) {
                int n = lstrlenW(buf);
                int c = key;
                if (n + 1 < len && c >= ' ') {
                    if (c < 0x100) {
                        buf[n] = (WCHAR)c;
                        buf[n + 1] = 0;
                        if (n>0 && c >= 0x80) {
                            if (buf[n - 1] >= 0x80 && buf[n - 1] < 0x100) {
                                WCHAR _text[8];
                                char  str[3] = {0};
                                str[0] = (char)buf[n-1];
                                str[1] = (char)buf[n];
                                MultiByteToWideChar(CP_ACP, 0, str, -1,  _text, 8);
                                buf[n-1] = 0;
                                lstrcatW(buf, _text);
                            }
                        }
                    } else {
                        lstrcatW(buf, (LPCWSTR)&c);
                    }
                }
            } else {
                ;
            }
        } while (kbhitEx(0xFFFF) > 0);
    }
EXIT:
    putimage(0, 0, &bg);
    if (!b_batchdraw_on) {
        WindowUnlock();
    }
    getflush();
    return ret;
}

float
_GetFPS(int add) {//��ȡ֡��
    static int      fps = 0;
    static int      fps_inv = 0;
    static LONGLONG time = 0;
    static float    flret = 0;
    static float    fret = 0;
    static float    fret_inv = 0;

    struct _graph_setting * pg = &graph_setting;
    LONGLONG cur = get_highfeq_time_ls(pg);
    if (add == 0x100) {
        fps += 1;
    } else if (add == -0x100) {
        fps += 1;
        fps_inv += 1;
    }
    if (cur - time >= 2000) {
        flret = fret;
        fret = (float)(fps * 10000.0 / (cur - time));
        fret_inv = (float)((fps - fps_inv) * 10000.0 / (cur - time));
        fps = 0;
        fps_inv = 0;
        time = cur;
    }
    if (add >0) {
        return (fret + flret) / 2;
    } else {
        return fret_inv;
    }
}

float
GetFPS() {
    return _GetFPS(0);
}

double
fclock() {
    struct _graph_setting * pg = &graph_setting;
    return get_highfeq_time_ls(pg) / 10000.0;
}

int
ege_compress(void *dest, unsigned long *destLen, const void *source, unsigned long sourceLen) {
    if (sourceLen == 0) {
        return -1;
    }
    {
        int ret = compress(
            (Bytef*)dest + sizeof(unsigned long),
            (uLongf*)destLen,
            (Bytef*)source,
            (uLong)sourceLen
            );
        ((unsigned long *)dest)[0] = sourceLen;
        *destLen += 4;
        return ret;
    }
}

int
ege_compress2(void *dest, unsigned long *destLen, const void *source, unsigned long sourceLen, int level) {
    if (sourceLen == 0) {
        return -1;
    }
    {
        int ret = compress2(
            (Bytef*)dest + sizeof(unsigned long),
            (uLongf*)destLen,
            (Bytef*)source,
            (uLong)sourceLen,
            level
            );
        *(unsigned long *)dest = sourceLen;
        *destLen += sizeof(unsigned long);
        return ret;
    }
}

unsigned long
ege_uncompress_size(const void *source, unsigned long sourceLen) {
    if (sourceLen > sizeof(unsigned long)) {
        return ((unsigned long *)source)[0];
    } else {
        return 0;
    }
}

int
ege_uncompress(void *dest, unsigned long *destLen, const void *source, unsigned long sourceLen) {
    *(uLongf*)destLen = ege_uncompress_size(source, sourceLen);
    if (*(uLongf*)destLen > 0) {
        int ret = uncompress(
            (Bytef*)dest,
            (uLongf*)destLen,
            (Bytef*)source + sizeof(unsigned long),
            (uLong)sourceLen - sizeof(unsigned long)
            );
        return ret;
    } else {
        return -1;
    }
}

} // namespace ege
