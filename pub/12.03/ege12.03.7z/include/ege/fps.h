#ifndef _EGE_FPS_H_
#define _EGE_FPS_H_

#ifndef _EGE_H_
#error include "fps.h" must after include "ege.h" or "graphics.h"
#endif

#include <stdio.h>

class fps : public egeControlBase
{
public:
    CTL_PREINIT(fps, egeControlBase) {
        // do sth. before sub objects' construct function call
    } CTL_PREINITEND;
    fps(CTL_DEFPARAM) : CTL_INITBASE(egeControlBase) {
        CTL_INIT; // must be the first line
        directdraw(true);
        enable(false);
    }

    void onDraw(PIMAGE pimg) const {
        char str[100];
        sprintf(str, "fps:%7.2f ", GetFPS());
        setcolor(WHITE, pimg);
        setfillcolor(BLACK, pimg);
        setbkmode(OPAQUE, pimg);
        setfont(12, 0, "����", pimg);
        outtextxy(0, 0, str, pimg);
    }
};

#endif /*_EGE_FPS_H_*/
